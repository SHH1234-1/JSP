package jspEx;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class BorderSearch
 */
@WebServlet("/jspEx/borderSearch")
public class BorderSearch extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String filter = request.getParameter("searchFilter"); //border.jsp에서 전체 제목 내용 작성자 중 선택된것과
		String search = request.getParameter("border_search"); //검색창에 입력된것
		System.out.println(filter);
		System.out.println(search);
		
		BorderMgrPool borderMgrPool = new BorderMgrPool();
		
		request.setAttribute("searchBorderList", borderMgrPool.getBorderList(filter, search)); //검색을 통해 걸러진 게시글을 searchBorderList로 setAttribute해준다 
		
		request.getRequestDispatcher("border").forward(request, response);
	}

}
