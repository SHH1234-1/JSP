package jspEx;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import db.DBConnectionMgr;

public class BorderMgrPool {
	private DBConnectionMgr pool = null;
	
	SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	Date now = new Date();
	String nowDate = dateFormat.format(now);
	
	public BorderMgrPool() {
		try {
			pool = DBConnectionMgr.getInstance();
		}catch(Exception e) {
			System.out.println("오류: DBConnection Pool 실패.");
		}
	}
	
	public ArrayList<BorderDtlBean> getBorderList(String filter, String search) { ////전체 제목 내용 작성자중에 선택된것이 filter 검색 input안에 들어있는값을 search를 매게변수로 하는 ArrayList<BorderDtlBean>의 getBorderList메소드
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		ArrayList<BorderDtlBean> list = new ArrayList<BorderDtlBean>();
		try {
			con = pool.getConnection();
			if(filter.equals("title")) { //filter값으로 제목이 선택되었다면
				sql = "select border_code, border_title, border_content, border_file, writer_name, border_date, border_count from border_dtl where border_title like ? order by border_code desc"; //from border_dtl에서 where border_title 이 여기서 입력받은것의 select뒤에 있는 것을 내림차순으로 출력
			}else if(filter.equals("content")) { //filter값으로 내용이 선택되었다면
				sql = "select border_code, border_title, border_content, border_file, writer_name, border_date, border_count from border_dtl where border_content like ? order by border_code desc";
			}else if(filter.equals("writer")) { //filter값으로 작성자가 선택되었다면
				sql = "select border_code, border_title, border_content, border_file, writer_name, border_date, border_count from border_dtl where writer_name like ? order by border_code desc";
			}else {
				sql = "select border_code, border_title, border_content, border_file, writer_name, border_date, border_count from border_dtl where border_title like ? or border_content like ? or writer_name like ? order by border_code desc";
			}
			
			pstmt = con.prepareStatement(sql);
			
			if(!filter.equals("all")) { //전체가 선택되지 않았을 경우
				pstmt.setString(1, "%" + search + "%"); //첫번째 물음표에 들어갈 search
			} else {
				pstmt.setString(1, "%" + search + "%");  //전체가 선택되면 첫번째 두번째 세번째 물음표에 검색input에 입력한 값을 전부 다 집어넣음
				pstmt.setString(2, "%" + search + "%");
				pstmt.setString(3, "%" + search + "%");
			}
			
			rs = pstmt.executeQuery();
			while(rs.next()) {  //검색을 통해서 걸러진 게시글을 전부 BorderDtlBean의 bean 객체에 담는다
				BorderDtlBean bean = new BorderDtlBean();  
				bean.setBorder_code(rs.getInt(1));
				bean.setBorder_title(rs.getString(2));
				bean.setBorder_content(rs.getString(3));
				bean.setBorder_file(rs.getString(4));
				bean.setWriter_name(rs.getString(5));
				bean.setBorder_date(rs.getString(6));
				bean.setBorder_count(rs.getInt(7));
				list.add(bean); //걸러진 리스트가 담긴 bean을 ArrayList<BorderDtlBean> list에 add해준다
			}
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			pool.freeConnection(con, pstmt, rs); //pool객체를 반환
		}
		return list; //list를 return해준다
	}
	
	
	public ArrayList<BorderDtlBean> getBorderList() {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		ArrayList<BorderDtlBean> list = new ArrayList<BorderDtlBean>();
		try {
			con = pool.getConnection();
			sql = "select border_code, border_title, border_content, border_file, writer_name, border_date, border_count from border_dtl order by border_code desc";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()) {  //데이터 베이스에 저장되어있는 게시글을 몽땅 다 가져옴
				BorderDtlBean bean = new BorderDtlBean();
				bean.setBorder_code(rs.getInt(1));
				bean.setBorder_title(rs.getString(2));
				bean.setBorder_content(rs.getString(3));
				bean.setBorder_file(rs.getString(4));
				bean.setWriter_name(rs.getString(5));
				bean.setBorder_date(rs.getString(6));
				bean.setBorder_count(rs.getInt(7));
				list.add(bean);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return list;
	}
	
	public BorderDtlBean getContent(int border_code) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		
		BorderDtlBean bean = new BorderDtlBean();
		
		try {
			con = pool.getConnection();
			sql = "select * from border_dtl where border_code = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, border_code);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				bean.setBorder_code(rs.getInt(1));
				bean.setBorder_title(rs.getString(2));
				bean.setBorder_content(rs.getString(3));
				bean.setBorder_file(rs.getString(4));
				bean.setWriter_name(rs.getString(5));
				bean.setWriter_ip(rs.getString(6));
				bean.setBorder_date(rs.getString(7));
				bean.setBorder_count(rs.getInt(8));
			}
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return bean;
	}
	
	public BorderDtlBean getPreBorderCode(int border_code) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		
		BorderDtlBean bean = new BorderDtlBean();
		
		try {
			con = pool.getConnection();
			sql = "select border_code, border_title from border_dtl where border_code = (select max(border_code) from border_dtl where border_code < ?)";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, border_code);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				bean.setBorder_code(rs.getInt(1));
				bean.setBorder_title(rs.getString(2));
			}
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return bean;
	}
	
	public BorderDtlBean getNextBorderCode(int border_code) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		
		BorderDtlBean bean = new BorderDtlBean();
		
		try {
			con = pool.getConnection();
			sql = "select border_code, border_title from border_dtl where border_code = (select min(border_code) from border_dtl where border_code > ?)";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, border_code);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				bean.setBorder_code(rs.getInt(1));
				bean.setBorder_title(rs.getString(2));
			}
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return bean;
	}
	
	public boolean borderInsert(BorderDtlBean borderDtlBean) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = null;
		
		try {
			con = pool.getConnection();
			sql = "insert into border_dtl values(0, ?, ?, ?, ?, ?,now(), 0, now(), now())";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, borderDtlBean.getBorder_title());
			pstmt.setString(2, borderDtlBean.getBorder_content());
			pstmt.setString(3, borderDtlBean.getBorder_file());
			pstmt.setString(4, borderDtlBean.getWriter_name());
			pstmt.setString(5, borderDtlBean.getWriter_ip());
			pstmt.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
			return false;
		}finally {
			pool.freeConnection(con, pstmt);
		}
		return true;
		
	}
	
}







